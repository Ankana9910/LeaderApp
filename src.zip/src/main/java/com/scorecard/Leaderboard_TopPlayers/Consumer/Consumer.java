package com.scorecard.Leaderboard_TopPlayers.Consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

    @KafkaListener(topics = "player-scores", groupId = "group_id")
    public void consume(String message) {
        System.out.println("Received message: " + message);
        // Parse the message and update player scores in your application
    }
}