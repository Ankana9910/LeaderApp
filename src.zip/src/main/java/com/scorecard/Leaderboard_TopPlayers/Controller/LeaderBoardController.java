package com.scorecard.Leaderboard_TopPlayers.Controller;


import com.scorecard.Leaderboard_TopPlayers.Entity.Player;
import com.scorecard.Leaderboard_TopPlayers.Producer.KafkaProducer;
import com.scorecard.Leaderboard_TopPlayers.Repository.PlayerRepository;
import com.scorecard.Leaderboard_TopPlayers.Service.LeaderBoardService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import com.scorecard.Leaderboard_TopPlayers.Service.LeaderboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/leaderboard")
public class LeaderBoardController {

    @Autowired
    private LeaderBoardService leaderboardService;

    @Autowired
    private KafkaProducer kafkaProducer;
    @Autowired
private PlayerRepository playerRepository;

    private static final Logger logger = LoggerFactory.getLogger(LeaderBoardController.class);
    public LeaderBoardController(LeaderBoardService leaderBoardService) {
        this.leaderboardService = leaderBoardService;
    }

    @GetMapping("/allPlayers")
    public List<Player> getAllPlayers() {
        logger.info("Request received to get all players");
        return leaderboardService.getAllPlayers();
        
    }

    @GetMapping("/top")
    
        public List<String[]> getTopPlayers() {
            ResponseEntity<String> response;
            
            return leaderboardService.getTopPlayers();
    }

   @PostMapping("/updateScore")
   
public ResponseEntity<String> updateScore(@RequestBody Player player) {
    logger.info("Request received to update score for player: {}", player.getName());
    Player existingPlayer = playerRepository.findById(player.getId()).orElse(null);
    ResponseEntity<String> response;

    if (existingPlayer != null) {
        int updatedScore = player.getScore();
        int existingScore = existingPlayer.getScore();
        
        if (updatedScore > existingScore) {
            existingPlayer.setScore(updatedScore);
            playerRepository.save(existingPlayer);
            kafkaProducer.sendMessage(player); // Send score update to Kafka topic
            response = ResponseEntity.ok("Score updated successfully");
        } else {
            // Log an error message
            logger.warn("Updated score is less than or equal to the existing score for player: {}", player.getName());
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Updated score is less than or equal to the existing score");
        }
    } else {
        // Log an error message
        logger.warn("Player not found: {}", player.getName());
        response = ResponseEntity.status(HttpStatus.NOT_FOUND).body("Player not found");
    }
    
    logger.info("Score update response for player {}: {}", player.getName(), response.getBody());
    return response;
}



    @PostMapping("/refreshScores")
    public ResponseEntity<String> refreshScores() {
        logger.info("Request received to refresh all scores");

        // Retrieve all players
        List<Player> players = playerRepository.findAll();

        // Update scores to 0 for each player
        for (Player player : players) {
            player.setScore(0);
            playerRepository.save(player);
        }

        logger.info("All scores refreshed successfully");
        return ResponseEntity.ok("All scores refreshed successfully");
    }

    @PostMapping("/addPlayer")
    public ResponseEntity<String> addPlayer(@RequestBody Player player) {
        logger.info("Request received to add player: {}", player.getName());

        // Check if the player already exists
        if (playerRepository.existsById(player.getId())) {
            logger.warn("Player with ID {} already exists", player.getId());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Player with the same ID already exists");
        }

        // Save the new player
        playerRepository.save(player);

        logger.info("Player {} added successfully", player.getName());
        return ResponseEntity.status(HttpStatus.CREATED).body("Player added successfully");
    }
}