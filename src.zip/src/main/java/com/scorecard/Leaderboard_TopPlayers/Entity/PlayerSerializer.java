package com.scorecard.Leaderboard_TopPlayers.Entity;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.common.serialization.Serializer;
import java.util.Map;

public class PlayerSerializer implements Serializer<Player> {

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
       
    }

    @Override
    public byte[] serialize(String topic, Player data) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsBytes(data);
        } catch (Exception e) {
            throw new RuntimeException("Error serializing Player object: " + e.getMessage());
        }
    }

    @Override
    public void close() {
        // No resources to release
    }
}