package com.scorecard.Leaderboard_TopPlayers.Entity;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scorecard.Leaderboard_TopPlayers.Repository.PlayerRepository;

//import org.hibernate.engine.jdbc.env.internal.LobCreationLogging_.logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@Service
public class PlayerService {
    private static final Logger logger = LoggerFactory.getLogger(PlayerService.class);

    private PlayerRepository playerRepository;
    private Map<Long, Player> players = new HashMap<>();
    


    @Autowired
    public PlayerService(PlayerRepository playerRepository) {
        this.playerRepository = playerRepository;
    }

    public Player getPlayerById(long id) {
        ResponseEntity<String> response;
        Player player = players.get(id);
        if (player == null) {
            logger.warn("Player not found: {}", player.getName());
            response = ResponseEntity.status(HttpStatus.NOT_FOUND).body("Player not found");

            
        }
        return player;
    }
}