package com.scorecard.Leaderboard_TopPlayers.Producer;



import com.scorecard.Leaderboard_TopPlayers.Entity.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducer {

    private static final String TOPIC = "player_scores";

    @Autowired
    private KafkaTemplate<String, Player> kafkaTemplate;

    public KafkaProducer(KafkaTemplate<String, Player> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(Player player) {
        kafkaTemplate.send(TOPIC, player);
    }
}