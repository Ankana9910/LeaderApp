package com.scorecard.Leaderboard_TopPlayers.Repository;

import com.scorecard.Leaderboard_TopPlayers.Entity.Player;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlayerRepository extends JpaRepository<Player, Long> {
}