package com.scorecard.Leaderboard_TopPlayers.Service;

import com.scorecard.Leaderboard_TopPlayers.Entity.Player;
import com.scorecard.Leaderboard_TopPlayers.Repository.PlayerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import jakarta.persistence.EntityManager;

import java.util.Comparator;
import java.util.List;
import java.util.logging.*;
import java.util.stream.Collectors;

@Service
public class LeaderBoardService {

    @Autowired
    private PlayerRepository playerRepository;

    public List<Player> getAllPlayers() {
        return playerRepository.findAll();
    }

   
    public List<String[]> getTopPlayers() {
                    List<Player> allPlayers = playerRepository.findAll();
                    
                    return allPlayers.stream()
                            .filter(player -> player.getScore() > 0)
                            .sorted(Comparator.comparingInt(Player::getScore).reversed())
                            .limit(5)
                            .map(player -> new String[]{player.getName(), String.valueOf(player.getScore())})
                            .collect(Collectors.toList());
      
    }
    public void updateScore(Player player) {
        Player existingPlayer = playerRepository.findById(player.getId()).orElse(null);
        if (existingPlayer != null) {
            existingPlayer.setScore(player.getScore());
            playerRepository.save(existingPlayer);
        }
    }

    
   
}
