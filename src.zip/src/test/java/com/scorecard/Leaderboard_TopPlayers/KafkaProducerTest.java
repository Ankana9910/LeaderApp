package com.scorecard.Leaderboard_TopPlayers;

import static org.mockito.Mockito.*;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.kafka.core.KafkaTemplate;

import com.scorecard.Leaderboard_TopPlayers.Entity.Player;
import com.scorecard.Leaderboard_TopPlayers.Producer.KafkaProducer;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaTemplate;

public class KafkaProducerTest {

    @Test
    public void testSendMessage() {
        // Mock KafkaTemplate
        KafkaTemplate<String, Player> kafkaTemplate = mock(KafkaTemplate.class);
        KafkaProducer kafkaProducer = new KafkaProducer(kafkaTemplate);

        // Create a player
        Player player = new Player();
        player.setName("TestPlayer");
        player.setScore(100);

        // Send message
        kafkaProducer.sendMessage(player);

        // Verify that KafkaTemplate's send method was called with the correct arguments
        verify(kafkaTemplate).send(eq("player_scores"), eq(player));
    }

    @Test
    public void testSendMessage_NullPlayer() {
        // Mock KafkaTemplate
        KafkaTemplate<String, Player> kafkaTemplate = mock(KafkaTemplate.class);
        KafkaProducer kafkaProducer = new KafkaProducer(kafkaTemplate);

        // Send message with null player
        kafkaProducer.sendMessage(null);

        // Verify that KafkaTemplate's send method was called with the correct arguments
        verify(kafkaTemplate).send(eq("player_scores"), eq(null));
    }
}
