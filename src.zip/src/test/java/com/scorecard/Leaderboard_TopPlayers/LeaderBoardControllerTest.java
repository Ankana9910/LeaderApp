/*package com.scorecard.Leaderboard_TopPlayers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scorecard.Leaderboard_TopPlayers.Controller.LeaderBoardController;
import com.scorecard.Leaderboard_TopPlayers.Entity.Player;
import com.scorecard.Leaderboard_TopPlayers.Producer.KafkaProducer;
import com.scorecard.Leaderboard_TopPlayers.Service.LeaderBoardService;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(LeaderBoardController.class)
public class LeaderBoardControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LeaderBoardService leaderBoardService;

    @MockBean
    private KafkaProducer kafkaProducer;
    private List<Player> players;

    @BeforeEach
    public void setUp() {
        players = new ArrayList<>();
        players.add(new Player("Player1", 100));
        players.add(new Player("Player2", 150));
        // You can initialize data or mock behaviors here if needed
    }

    @Test
    public void testUpdateScore() throws Exception {
        Player player = new Player();
        player.setName("TestPlayer");
        player.setScore(100);

        doNothing().when(leaderBoardService).updateScore(any(Player.class));

        mockMvc.perform(MockMvcRequestBuilders.post("/leaderboard/updateScore")
                .content(asJsonString(player))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    // Utility method to convert object to JSON string
    private String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
*/